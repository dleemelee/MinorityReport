
public class Members {
	
	
	String fingerprintID;
	
	int casesAssociatedM;
	

	public Members(String fingerprintID) {
		this.fingerprintID = fingerprintID;
	}

	public String getFingerprintID() {
		return fingerprintID;
	}

	public void setFingerprintID(String fingerprintID) {
		this.fingerprintID = fingerprintID;
	}

	public int getCasesAssociatedM() {
		return casesAssociatedM;
	}

	public void setCasesAssociatedM(int casesAssociatedM) {
		this.casesAssociatedM = casesAssociatedM;
	}

}
