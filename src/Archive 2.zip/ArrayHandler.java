
//Organizes the array
public class ArrayHandler {
	ArrestArray myAA;
	VictimArray myVA;
	
	public ArrayHandler(){
		myAA = new ArrestArray();
		myVA = new VictimArray();
	}

	public ArrestArray getMyAA() {
		return myAA;
	}

	public void setMyAA(ArrestArray myAA) {
		this.myAA = myAA;
	}

	public VictimArray getMyVA() {
		return myVA;
	}

	public void setMyVA(VictimArray myVA) {
		this.myVA = myVA;
	}
	
	
	
	
	
	
	
	
	

}
