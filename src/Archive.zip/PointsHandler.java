public class PointsHandler {

	private int points;
	
	public PointsHandler(Person p) {
		Crimes(p);

	}
	
	void Crimes(Person p){
		int temp = 0;
		for(int x:p.Crimes){
			temp += x;
		}
		p.points += temp;
	}

}
