
public class Play {
	
	public static void main(String[] args) {
		
		PersonArray PA = new PersonArray();
		PA.init();
		
		
		for(Person x: PA.PA){
			PointsHandler PH = new PointsHandler(x);
		}
		
		System.out.println(PA.PA.get(0).points);
		for(Person x: PA.PA){
			
		}
		
	}

}
