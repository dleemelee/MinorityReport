import java.util.ArrayList;


public class Point {
	
	ArrayHandler AH;
	
	PersonArray PA;
	
	FactionArray FA;
	
	
	Point(){
		AH = new ArrayHandler();
		
		PA = new PersonArray();
		
		FA = new FactionArray();
	}
	
	public void calcPoints()
	{
		
		
		
	}
	
	
	
	
	
	
	

}
